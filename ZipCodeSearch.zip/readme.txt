Data Source: http://www.census.gov/geo/www/gazetteer/places2k.html

Zip Contents:

* mssql_stored_proc.txt - includes stored procedure for performing zip search on MS SQL server
* mysql_query.txt - includes sample query for performing zip search on MySQL server
* readme.txt - this file
* ZipCodes.mdb - Zip Codes database, with ZipCode, Latitude, Longitude, and State fields.  Use this to import data to other databases.  Radius seaches will NOT work with MS Access.
* ZipCodes.sql - MySQL Database Dump for importing data into MySQL
